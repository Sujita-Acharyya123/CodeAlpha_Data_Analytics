# CodeAlpha Data Analytics Tasks

**Candidate:** Sujita Acharya  
**Project:** Unemployment Rate Analysis  
**Repository name:** `codealpha_tasks`

## Tasks completed
- **Task 2 — Exploratory Data Analysis (EDA):** inspected the dataset, checked data types, missing values and duplicate dates, calculated descriptive statistics, and compared unemployment rates by the period label supplied in the data.
- **Task 3 — Data Visualization:** created a monthly trend chart, a period comparison box plot, and a chart of average rates by calendar month.

## Dataset
The project uses the supplied `cleaned_unemployment_data.csv` file. It contains 30 valid monthly observations from 2019-01-01 to 2021-06-01, with the columns `date`, `unemployment_rate`, `period`, and `covid_period`.

The project does not claim that the data represents a particular country or population because that information was not included in the supplied files.

## Project structure
```text
codealpha_tasks/
├── data/
│   ├── cleaned_unemployment_data.csv
│   ├── provided_period_summary.csv
│   └── provided_confusion_matrix_reference.csv
├── outputs/
│   ├── charts/
│   └── period_summary_recomputed.csv
├── src/
│   └── analysis.py
├── Sujita_Acharya_CodeAlpha_Data_Analytics.ipynb
├── requirements.txt
└── README.md
```

## Setup and run
1. Install Python 3.9 or later.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start Jupyter:
   ```bash
   jupyter notebook
   ```
4. Open `Sujita_Acharya_CodeAlpha_Data_Analytics.ipynb` and run the cells.

Run the script version from the project root:
```bash
python src/analysis.py
```

## Data quality and analysis notes
- Valid observations used: 30
- Date range: 2019-01-01 to 2021-06-01
- Missing values after cleaning: 0
- Duplicate dates: 0
- Overall mean unemployment rate: 8.01
- Overall median unemployment rate: 6.95
- Minimum: 6.00; maximum: 21.00

The `confusion_matrix.csv` supplied with the reference files appears to describe a three-class classification result and is not part of this unemployment-rate EDA. It is retained separately in `data/` for reference and is not combined with the unemployment dataset.

## Important
The analysis describes only the supplied data. It does not establish causes for changes in unemployment, and no external dataset or unverified execution results have been added.
