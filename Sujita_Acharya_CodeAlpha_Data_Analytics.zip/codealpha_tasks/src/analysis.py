
# CodeAlpha Data Analytics Internship Project
# Candidate: Sujita Acharya
# Tasks completed: Task 2 - Exploratory Data Analysis (EDA); Task 3 - Data Visualization

import pandas as pd
import matplotlib.pyplot as plt

# Load the supplied cleaned dataset
df = pd.read_csv("data/cleaned_unemployment_data.csv")
df["date"] = pd.to_datetime(df["date"], errors="coerce")
df["unemployment_rate"] = pd.to_numeric(df["unemployment_rate"], errors="coerce")
df = df.dropna(subset=["date", "unemployment_rate"]).sort_values("date")

# Basic inspection
print("Shape:", df.shape)
print("\nData types:\n", df.dtypes)
print("\nMissing values:\n", df.isna().sum())
print("\nDuplicate dates:", df.duplicated(subset=["date"]).sum())
print("\nSummary statistics:\n", df["unemployment_rate"].describe())

# EDA: compare the two periods supplied in the data
period_summary = (
    df.groupby("covid_period")["unemployment_rate"]
      .agg(["count", "mean", "median", "min", "max"])
      .reset_index()
)
print("\nPeriod summary:\n", period_summary)

# Visualization 1: monthly trend
plt.figure(figsize=(10, 5))
plt.plot(df["date"], df["unemployment_rate"], marker="o")
plt.title("Monthly Unemployment Rate")
plt.xlabel("Date")
plt.ylabel("Unemployment rate (%)")
plt.xticks(rotation=45)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()

# Visualization 2: distribution by period
periods = [p for p in ["Before 2020", "2020 onward"] if p in df["covid_period"].unique()]
values = [df.loc[df["covid_period"] == p, "unemployment_rate"] for p in periods]
plt.figure(figsize=(8, 5))
plt.boxplot(values, tick_labels=periods)
plt.title("Unemployment Rate by Period")
plt.xlabel("Period")
plt.ylabel("Unemployment rate (%)")
plt.grid(True, axis="y", alpha=0.3)
plt.tight_layout()
plt.show()

# Visualization 3: average by calendar month
df["month"] = df["date"].dt.month_name()
month_order = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"]
monthly_avg = df.groupby("month")["unemployment_rate"].mean().reindex(month_order).dropna()
plt.figure(figsize=(9, 5))
plt.bar(monthly_avg.index, monthly_avg.values)
plt.title("Average Unemployment Rate by Calendar Month")
plt.xlabel("Month")
plt.ylabel("Average unemployment rate (%)")
plt.xticks(rotation=40, ha="right")
plt.tight_layout()
plt.show()
